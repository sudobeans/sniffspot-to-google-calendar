# sniffspot-to-google-calendar
A browser extension that converts Sniffspot reservations into a schedule that can be put in Google Calendar.
